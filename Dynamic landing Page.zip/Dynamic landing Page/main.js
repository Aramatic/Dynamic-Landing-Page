// DOm elements

 const time = document.getElementById('time'),
  greeting = document.getElementById('greeting'),
  name= document.getElementById('name'),
  focus= document.getElementById('focus');

  //Show time

  function showTime() {
    let today = new Date(),
    hour = today.getHours(),
    min = today.getMinutes(),
    sec = today.getSeconds();

    const amPm = hour >= 12 ? 'PM' : 'AM';

    // 12hr format

    hour = hour % 12 || 12;
    //output

    time.innerHTML  = `${hour}<span>:</span>${addZer0(min)}<span>:</span>${addZer0(sec)}`;

    setTimeout(showTime, 1000);

  }

  // RUn
  showTime();
  //add zero
  function addZer0(n){
    return (parseInt(n, 10)< 10 ? '0' : '')+ n;
  }

  // function set background

  function setBgGreet() {
    let today = new Date(),
     hour = today.getHours();

     if(hour < 12) {
        document.body.style.backgroundImage = "url('moarning.jpg')";
        greeting.textContent= 'Good Morning';
     }
     else if(hour < 18){
        document.body.style.backgroundImage = "url('afternoon.jpeg')";
        greeting.textContent= 'Good Afternoon';
     }
     else{
        document.body.style.backgroundImage = "url('night view.jpeg')";
        greeting.textContent= 'Good Evening';
        document.body.style.color = 'white';

     }
     

  }
  setBgGreet();

  function getName() {
   if(localStorage.getItem('name')===null){
      name.textContent='[Enter Name]';
   }
   else{
      name.textContent=localStorage.getItem('name' );
   }
  }
   getName();
// setName
function setName(e){
   if(e.type=== 'keypress'){
      //make sure you press entered
      if(e.which==13 || e.keyCode==13){
         localStorage.setItem('name', e.target.innerText);
         name.blur();
      }

   }else{
      localStorage.setItem('name', e.target.innerText);
   }
}

function getFocus() {
   if(localStorage.getItem('focus')===null){
      focus.textContent= '[Enter focus]';
   }
   else{
      focus.textContent = localStorage.getItem('focus');
   }
}
getFocus();

//set focus
function setFocus(e) {
   if(e.type === 'keypress'){
      // Make sure your enter pressed
      if(e.which == 13 || e.keyCode==13){
         localStorage.setItem=('focus', e.target.innerText);
         focus.blur();
      }
   }
   else{
      localStorage.setItem=('focus', e.target.innerText);
   }
}

name.addEventListener('keypress', setName);
name.addEventListener('blur', setName);


focus.addEventListener('keypress', setFocus);
focus.addEventListener('blur', setFocus);


  
  